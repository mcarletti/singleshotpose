import numpy as np
import os
from shutil import copy2
import matplotlib.pyplot as plt
import cv2

PARENT = 'data/'
OUTDIRIMAGES = 'JPEGImages/'
OUTDIRLABELS = 'labels/'
IMEXT = '.jpg'
PREFIX = 'LINEMOD/cup/'+OUTDIRIMAGES
CLASSID = 13

class Data(object):
    def __init__(self):
        super(Data, self).__init__()
        self.I = []
        self.R = []
        self.T = []

def readmatrix(i):
    with open(PARENT+'rot'+str(i)+'.rot','r') as fp:
        lines = fp.readlines()
    R = np.asarray(''.join(lines[1:]).replace('\n','').split())
    R = R.astype(np.float32).reshape(3,3)
    with open(PARENT+'tra'+str(i)+'.tra','r') as fp:
        lines = fp.readlines()
    t = np.asarray(''.join(lines[1:]).replace('\n','').split())
    t = t.astype(np.float32).reshape(3,1) / 100 # from cm to m
    return R,t

nSamples = int(len(os.listdir(PARENT))/4)

if not os.path.exists(OUTDIRIMAGES):
    os.makedirs(OUTDIRIMAGES)
for i in range(nSamples):
    src = PARENT+'color'+str(i)+IMEXT
    dst = OUTDIRIMAGES+str(i).zfill(6)+IMEXT
    copy2(src,dst)

I = np.sort(os.listdir(OUTDIRIMAGES))
R = np.zeros((nSamples,3,3),dtype=np.float32)
T = np.zeros((nSamples,3,1),dtype=np.float32)

for i in range(nSamples):
    R[i],T[i] = readmatrix(i)

indices = np.random.permutation(nSamples)
test_size = int(0.85 * nSamples)
test_idx = np.sort(indices[:test_size])
train_idx = np.sort(indices[test_size:])

test = Data()
test.I = I[test_idx]
test.R = R[test_idx]
test.T = T[test_idx]

train = Data()
train.I = I[train_idx]
train.R = R[train_idx]
train.T = T[train_idx]

np.savetxt('test.txt',[PREFIX+x for x in test.I],fmt='%s')
np.savetxt('train.txt',[PREFIX+x for x in train.I],fmt='%s')

#%%

class MeshPly:
    def __init__(self, filename, color=[0., 0., 0.]):

        f = open(filename, 'r')
        self.vertices = []
        self.colors = []
        self.indices = []
        self.normals = []

        vertex_mode = False
        face_mode = False

        nb_vertices = 0
        nb_faces = 0

        idx = 0

        with f as open_file_object:
            for line in open_file_object:
                elements = line.split()
                if vertex_mode:
                    self.vertices.append([float(i) for i in elements[:3]])
                    self.normals.append([float(i) for i in elements[3:6]])

                    if elements[6:9]:
                        self.colors.append([float(i) / 255. for i in elements[6:9]])
                    else:
                        self.colors.append([float(i) / 255. for i in color])

                    idx += 1
                    if idx == nb_vertices:
                        vertex_mode = False
                        face_mode = True
                        idx = 0
                elif face_mode:
                    self.indices.append([float(i) for i in elements[1:4]])
                    idx += 1
                    if idx == nb_faces:
                        face_mode = False
                elif elements[0] == 'element':
                    if elements[1] == 'vertex':
                        nb_vertices = int(elements[2])
                    elif elements[1] == 'face':
                        nb_faces = int(elements[2])
                elif elements[0] == 'end_header':
                    vertex_mode = True

def get_3D_corners(vertices):
    
    min_x = np.min(vertices[0,:])
    max_x = np.max(vertices[0,:])
    min_y = np.min(vertices[1,:])
    max_y = np.max(vertices[1,:])
    min_z = np.min(vertices[2,:])
    max_z = np.max(vertices[2,:])

    corners = np.array([[min_x, min_y, min_z],
                        [min_x, min_y, max_z],
                        [min_x, max_y, min_z],
                        [min_x, max_y, max_z],
                        [max_x, min_y, min_z],
                        [max_x, min_y, max_z],
                        [max_x, max_y, min_z],
                        [max_x, max_y, max_z]])

    corners = np.concatenate((np.transpose(corners), np.ones((1,8)) ), axis=0)
    return corners

def get_camera_intrinsic():
    K = np.zeros((3, 3), dtype='float64')
    K[0, 0], K[0, 2] = 572.4114, 325.2611
    K[1, 1], K[1, 2] = 573.5704, 242.0489
    K[2, 2] = 1.
    return K

mesh = MeshPly('cup.ply')
meshScale = np.loadtxt('distance.txt').item()
vertices = np.c_[np.array(mesh.vertices), np.ones((len(mesh.vertices), 1))].transpose()
corners3D = get_3D_corners(vertices)
K = get_camera_intrinsic()

if not os.path.exists(OUTDIRLABELS):
    os.makedirs(OUTDIRLABELS)
corners3D = corners3D.transpose()[:,:3].astype(np.float32)
centroid = np.mean(corners3D,axis=0).reshape(1,3)
xRange = np.abs(np.max(corners3D[:,0]) - np.min(corners3D[:,0])) / meshScale
yRange = np.abs(np.max(corners3D[:,1]) - np.min(corners3D[:,1])) / meshScale
points3D = np.concatenate((centroid,corners3D),axis=0)
points2D = np.zeros((nSamples,21),dtype=np.float32)
image = plt.imread('JPEGImages/000000.jpg')
H,W,_ = image.shape
for i in range(nSamples):
    rotV, _ = cv2.Rodrigues(R[i])
    p2D, _ = cv2.projectPoints(points3D, rotV, T[i], K, None)
    p2D = p2D.squeeze().reshape(18)
    p2D[[0,2,4,6,8,10,12,14,16]] /= W
    p2D[[1,3,5,7,9,11,13,15,17]] /= H
    points2D[i] = np.array([CLASSID] + p2D.tolist() + [xRange,yRange]).reshape(1,21)
    np.savetxt(OUTDIRLABELS+str(i).zfill(6)+'.txt',points2D[i],fmt='%s',newline=' ')

#%%

'''
def drawAxis(img, R, t, K, scale=1):
    import cv2
    # unit is mm
    rotV, _ = cv2.Rodrigues(R)
    points = scale * np.float32([[1, 0, 0], [0, 1, 0], [0, 0, 1], [0, 0, 0]]).reshape(-1, 3)
    axisPoints, _ = cv2.projectPoints(points, rotV, t, K, (0,)*points.shape[0])
    frame = img.copy()
    frame = cv2.line(frame, tuple(axisPoints[3].ravel()), tuple(axisPoints[0].ravel()), (255,0,0), 3)
    frame = cv2.line(frame, tuple(axisPoints[3].ravel()), tuple(axisPoints[1].ravel()), (0,255,0), 3)
    frame = cv2.line(frame, tuple(axisPoints[3].ravel()), tuple(axisPoints[2].ravel()), (0,0,255), 3)
    return frame

def drawBBox(img, R, t, K, scale=3):
    import cv2
    # unit is mm
    rotV, _ = cv2.Rodrigues(R)
    points = corners3D.transpose()[:,:3].astype(np.float32)
    axisPoints, _ = cv2.projectPoints(points, rotV, t, K, (0,)*points.shape[0])
    frame = img.copy()
    for i in range(axisPoints.shape[0]):
        p = tuple(axisPoints[i][0].astype(int).tolist())
        frame = cv2.circle(frame,p,scale,(0,255,255), -1)
    return frame

image = plt.imread('JPEGImages/000000.jpg')
frame = drawAxis(image, R[0], T[0], K, 3)
plt.imshow(frame)
plt.show()

for i in range(100):
    image = plt.imread('JPEGImages/'+str(i).zfill(6)+'.jpg')
    frame = drawAxis(image, R[i], T[i], K, meshScale)
    frame = drawBBox(image, R[i], T[i], K, 3)
    plt.imshow(frame)
    plt.pause(0.1)
'''