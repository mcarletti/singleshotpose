% clear workspace
close all;
clear;
clc;

% load point cloud
[x,y,z] = xyzread('../object.xyz');

% remove invalid points
invalid_idx = logical(1 - int32(isnan(x)+isnan(y)+isnan(z)+isinf(x)+isinf(y)+isinf(z)));
x = x(invalid_idx);
y = y(invalid_idx);
z = z(invalid_idx);

% invert z axis and convert from cm to m
z = -z;
p = [x y z] ./ 100;

%%

% show pointcloud
figure;
hold on;
grid on;
axis equal;
cameratoolbar;
scatter3(x,y,z);
xlabel('X');
ylabel('Y');
zlabel('Z');

%%

ptc = pointCloud(p);
pcwrite(ptc,'../cup.ply');

